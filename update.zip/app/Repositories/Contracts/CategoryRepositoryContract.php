<?php

namespace App\Repositories\Contracts;

interface CategoryRepositoryContract
{
    public function search($fields);
}