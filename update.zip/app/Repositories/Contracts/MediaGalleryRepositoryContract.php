<?php

namespace App\Repositories\Contracts;

interface MediaGalleryRepositoryContract
{
    public function search($fields);
}